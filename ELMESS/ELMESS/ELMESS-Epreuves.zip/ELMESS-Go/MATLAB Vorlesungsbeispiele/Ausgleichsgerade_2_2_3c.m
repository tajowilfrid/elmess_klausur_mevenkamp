% Ausgleichsgerade_2_2_3c.m
% L�sung zur Aufgabe aus Skriptkapitel 2.2.3 mit verk�rzter Datenreihe
% Mev, 13.10.16
% 28.9.18: Anpassung Octave
%
v=ver;if(strcmp(v(1).Name,'Octave')) isMATLAB = 0; else, isMATLAB = 1; end
format compact

%% Messwertpaare (Strom, Spannung) als Spaltenvektoren
I = [0.2; 0.5; 1.0];
U = [33; 29; 23];

%% 3 von etlichen M�glichkeiten, die Ausgleichsgerade zu berechnen
% 1.) polyfit bietet sich in Matlab an (siehe "doc polyfit")
% (Mit Hilfe eines zweiten Ausgabearguments l�sst sich dabei auch die
% Unsicherheit der Steigung und des y-Achsabschnitts ermitteln,
% allerdings nur mittels einer sehr unanschaulichen Formel.
[p,s] = polyfit(I,U,1); m = p(1), b = p(2)
covp = inv(s.R)*inv(s.R)'*s.normr^2/s.df;
if isMATLAB
    sm = sqrt(covp(1,1))
    sb = sqrt(covp(2,2))
else
    sm = sqrt(covp(2,2))
    sb = sqrt(covp(1,1))
end
    
% 2.) Berechnung nach Skript-Kapitel 2.1.1 und 2.1.2
N = length(I);
sI2 = sum((I-mean(I)).^2)/(N-1);    % oder (I-mean(I))'.*(I-mean(I))/(N-1)
sIU = sum((I-mean(I)).*(U-mean(U)))/(N-1);  % (I-mean(I))'*(U-mean(U))/(N-1)
m = sIU/sI2
b = mean(U)-m*mean(I)
sU = sqrt(sum((U-mean(U)).^2)/(N-1));
rIU = sIU/sU/sqrt(sI2);
smrel = sqrt(1/rIU^2-1)/sqrt(N-2);
sm = abs(smrel*m)
sb = sm*sqrt(mean(I.*I))

% 3.) Nach Kap. 2.1.1 und 2.1.2, aber mittels cov (siehe "doc cov")
CIU = cov([I,U]);     % sI^2 = cov(1,1), sU^2 = cov(2,2), sIU = cov(1,2) !
m = CIU(1,2)/CIU(1,1)
b = mean(U)-m*mean(I)
BIU = CIU(1,2)^2/CIU(1,1)/CIU(2,2);
smrel = sqrt(1/BIU-1)/sqrt(N-2);
sm = abs(smrel*m)
sb = sm*sqrt(mean(I.*I))

% Im Command Window pr�fen, dass alle 3 Rechenwege das gleiche Ergebnis
% liefern!

%% Grafik
Iag = [0, 1.2];         % Werte der x-Achse f�r die Ausgleichsgerade, zwei gen�gen
Uag = polyval(p,Iag);   % zugeh�rige y-Werte
plot(I,U,'*',Iag,Uag,'r')
grid
set(gca,'xminorgrid','on','yminorgrid','on')
xlabel('Strom I [A]')
ylabel('Spannung U [V]')
legend('Messwerte','Ausgleichsgerade','Location','SouthWest')
hold off