function [] = floetentoene()
% FLOETENTOENE
% Erm�glicht eine 5-Sekunden Aufnahme �ber den Mic-Eingang
% des PC und berechnet und zeigt anschlie�end das Spektrum
%
% Anders als �blich wird das Spektrum bis zur vollen Abtastrate gezeigt
% und nicht nur bis zur H�lfte, um die Spiegelsymmetrie bezogen
% auf die Achse bei der halben Abtastrate deutlich zu machen.

% Mev, 27.10.2008
% 7.12.2016: Umstellung auf myfft()

% Abtastrate der Aufnahme abfragen, mit Defaultwert
fTdef = 8000;
fT = input(['Abtastfrequenz f�r diese Aufnahme [', num2str(fTdef), ']? fT = '])
if isempty(fT)
    fT = fTdef;
end

% Aufnahme starten
%--------------------------------------------------------------------
r = audiorecorder(fT, 16, 1);

disp('Bitte 5 Sek. ins Mikro fl�ten oder einen Ton summen ...')
record(r);
for i = 1:5
    disp(i)
    pause(1)
end
stop(r);

% Aufnahme abspielen
%--------------------------------------------------------------------
disp('und so hat''s geklungen ...')
p = play(r);    % abspielen
pause(5)        % Zeit geben zum Abspielen


% Spektrum dieser Aufnahme (gemitteltes-Spektrum mit myfft())
%--------------------------------------------------------------------
floetenton = getaudiodata(r, 'double'); % Aufnahme als Array im Workspace
ns = length(floetenton);
nfft = 4096;
li = 1:nfft;			% Indexvektor des Folgenausschnitts
dl = nfft/4;            % Abstand aufeinanderfolgender Ausschnitte
f = (li-1)'/nfft*fT;    % Frequenzachse des Spektrums
win = hanning(nfft);    % Leckeffekt verringern durch Hanning
Sp = zeros(nfft,1);
nspec = 0;
while li(nfft) <= ns
    nspec = nspec + 1;
    flk = floetenton(li);
    S = myfft((flk-mean(flk)).*win);
    Sp = Sp + abs(S);
    li = li + dl;
end
Sp = Sp / nspec;

% Plot
%--------------------------------------------------------------------
figure(1)
clf
set(gcf,'units','normalized')
set(gcf,'position',[0.35 0.3,0.57,0.52])

axes('position',[0.08, 0.1, 0.89, 0.83])
hl1 = plot(f,Sp);
set(hl1,'linewidth',1.5)
set(gca,'xlim',[0 fT])
grid
title('Spektrum der Aufnahme')
xlabel('Frequenz [Hz]')

function s = myfft(s)
% MYFFT     Implementierung des FFT-Algorithmus
%
% "in place"-"decimation in time"-Algorithmus
% aus FORTRAN (Code aus Oppenheim, Schafer, 1989) nach Matlab �bertragen
%
% Input:
%   s   double Array der Dimension n (n muss Zweierpotenz sein)
%
% Output:
%   s   Fourier-Transformierte (DFT) der Eingangsfolge s
%       s(1) = S_0
%       s(2) = conj(s(n)) = S_1
%       s(3) = conj(s(n-1)) = S_2
%       ...
%       s(n/2) = conj(s(n/2+2)) = S_(n/2-1)
%       s(n/2+1) = S_(n/2)
%

% M. Mevenkamp, 7.11.2013
% Kommentar zum (schrecklichen) Code: der eigentliche Algorithmus ist hier
% kaum noch erkennbar, das liegt an der 1:1-�bertragung aus FORTRAN.
% Man sieht aber gut, wie wenige und vor allem wie einfache Operationen nur
% ben�tigt werden, um das Spektrum zu berechnen - simple Multiplikationen
% und Additionen.

%% Parameter
if nargin == 0
    error('Aufruf: S = myfft(s);')
end

[n,m] = size(s);
if n < m
    s = s';             % s wird als Spaltenvektor verarbeitet
    [n,m] = size(s);
end
if m ~= 1
    error('Input s muss ein eindimensionales Array sein!')
end
ldn = round(log2(n));
if n ~= 2^ldn
    error('Dimension von s muss eine Zweierpotenz sein!')
end

%% Start (Umsortieren der Elemente von s)
j = 1;
for i = 1:n-1
    if j < i
        t = s(j);
        s(j) = s(i);
        s(i) = t;
    end
    k = n/2;
    while k < j
        j = j-k;
        k = k/2;
    end
    j = j+k;
end

%% "Butterfly" - Algorithmus
j = sqrt(-1);
for l = 1:ldn
    le = 2^l;
    le2 = le/2;
    u = 1+0*j;
    w = cos(pi/le2) - j*sin(pi/le2);
    for k = 1:le2
        for i = k:le:n
            ip = i+le2;
            t = s(ip)*u;
            s(ip) = s(i)-t;
            s(i) = s(i)+t;
        end
        u = u*w;
    end
end


function w = hanning(n)
% HANNING(N) liefert das N-Werte Hanning-Fenster als Spaltenvektor
w = 0.5*(1 - cos(2*pi*(1:n)'/(n+1)));

