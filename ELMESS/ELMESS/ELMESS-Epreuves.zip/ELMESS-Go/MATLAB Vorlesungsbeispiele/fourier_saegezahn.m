function   fourier_saegezahn()
% Erzeugt eine S�gezahn-Wertefolge und berechnet das Spektrum
% mit Grafik

% S�gezahnschwingung mit Amplitude A und Periodendauer T
%--------------------------------------------------------------------
A = 10;
T = 20;
nT = 50;                % Zahl der Perioden in der Folge
N = nT * T;
t = (0:N-1)';           % Abtastperiode T_S = 1
x = rem(t,T)*A/T;

% Fourier-Transformation
%--------------------------------------------------------------------
Xc = fft(x);                        % komplexes Spektrum, N Werte
nc = length(Xc);

% Reelles Amplitudenspektrum (nur positive Frequenzen)
nf = nc/2;
f = (0:nf)'/N;
X = [abs(Xc(1)); abs(Xc(2:nf))+abs(Xc(nc:-1:nf+2)); abs(Xc(nf+1))] / N;

% Komplexes Amplitudenspektrum
% Frequenzen aufsteigend sortiert, h�chste negative Frequenz zuerst
fc = (-nf+1:nf)'/N;
Xc = [abs(Xc(nf+2:nc)); abs(Xc(1:nf+1))] / N;


% Grafik
%--------------------------------------------------------------------
figure(1)
clf
set(gcf,'units','normalized')
set(gcf,'position',[0.05 0.05,0.87,0.82])

h = plotpos(3,0.05,0.08,0.08);

% Zeitverlauf
axes(h(1))
hl1 = plot(t,x);
legend('Zeitverlauf')
ylabel('x(t)')
title('Spektrum einer S�gezahnschwingung')
grid

% komplexes Spektrum
axes(h(2))
hl1 = plot(fc,Xc);
set(hl1,'linewidth',1.5)
legend('Betrag des komplexen Spektrums')
ylabel('|X(j\omega)|')
grid

% Amplitudenspektrum
axes(h(3))
hl1 = stem(f,X);
set(hl1,'linewidth',1.5)
legend('Amplitudenspektrum')
ylabel('|X(\omega)|')
grid

xlabel('Frequenz')
text(0.94,-0.06,'Hz','units','normalized')
