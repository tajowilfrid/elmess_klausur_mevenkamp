% RCstep_lsqfit
%
% �bergangsfunktion RC-Tiefpass mit Anpassung durch
% Ausgleichsfunktion (S�ttigungsverlauf) mittels lsqcurvefit
% aus der Optimization TB

% Mev, 10/2017

%% Messreihe einlesen (hier: erzeugen)
%----------------------------------------------------------------------
rc = 33e3*33e-6;
N = 50;
t = (0:N-1)'*5*rc/N;
u = 0.05*randn(size(t));
t0 = t(N/10);
u(t>t0) = u(t>t0) + 2*(1-exp(-(t(t>t0)-t0)/rc));

%% Fit
%----------------------------------------------------------------------
% Theoretischer Verlauf: u(t) = u0 f�r t < t0  und
% u(t) = u0 + (u1-u0)*(1-exp(-(t-t0)/tau))  f�r t > t0
% Suche mit plausiblen Anfangssch�tzwerten starten:
% par = [t0, u0, u1, tau] 
urc = @(par,t) (t<par(1))*par(2) + (t>=par(1)).*(par(2) + (par(3) - par(2)) ...
                                        * (1 - exp(-(t-par(1))/par(4))));
par = [t(end)/10; 0; 2; 0.1]; 
[paropt, resnorm] = lsqcurvefit(urc, par, t, u);

sprintf('\nMittlere Abweichung der Messpunkte von der Ausgleichskurve')
sprintf('delta_u = %6.3f', sqrt(resnorm/length(u)))

%% Grafik
figure(1)
clf
set(gcf,'units','normalized')
set(gcf,'position',[0.2 0.2,0.7,0.6])
h = axes('position', [0.08,0.11,0.88,0.85]);

hl = plot(t, u, 'bo', t, urc(paropt,t), 'g');
set(hl(1),'linewidth',2)
set(hl(2),'linewidth',1.5)
grid
set(h,'ylim',[-0.5, 2.5])
set(h,'fontsize',12)
ylabel('Spannung u(t) [V]')
xlabel('Zeit [s]')
legend('Messwerte', 'Ausgleichskurve ("fit")','Location','NorthWest')
text(0.55,0.05,[sprintf('Optimale Parameter: t0 = %6.2f ,  U0 = %6.2f , ' , paropt(1),paropt(2)) ...
          sprintf('U1 = %6.2f ,  \\tau = %6.2f', paropt(3),paropt(4))], ...
    'units', 'normalized','fontsize',12)
